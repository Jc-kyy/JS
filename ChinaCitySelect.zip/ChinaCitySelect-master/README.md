# ChinaCitySelect
基于jQuery的省市县选择框三级联动插件

# Demo
https://yusoo.github.io/ChinaCitySelect/

# License
MIT